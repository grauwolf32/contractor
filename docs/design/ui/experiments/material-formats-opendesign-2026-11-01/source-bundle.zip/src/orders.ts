async function getOrder(req, res) {
  const order = await db.orders.findById(req.params.id);
  return res.json(order);
}
