# Shop API source bundle

Saved synthetic source and documentation for the order service.

## Contents
- `src/orders.ts` — saved handler
- `docs/review.md` — review notes
- `assets/sample.bin` — binary example
